package com.example.demoocp.gitocp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitOcpApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitOcpApplication.class, args);
	}

}
